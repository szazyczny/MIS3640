"""
What is the most interesting/funny/cool thing(s) about Python that you learned from this class or from somewhere else.

You can use code or a short paragraph to illustrate it.
"""


"""
I think Python is a really interesting tool. It is very cool that one can create so many programs for various reasons out of nothing. I like the countdown functions and think they are fun like the blast off example. There were many moments in class where I was amazed by the power of Python. I think it is interesting to analyze texts and create specific functions to do so. I am not an expert in math so I found the text analysis more interesting and applicable, especially with social media and online reviews.

It is amazing to see the amount of resources available online with people who have created code and also help others trying to learn the program. I am not a huge fan of Python because it is so intangible to me. I prefer working with datasets for analysis which is part of the reason this course is so difficult. I have found this course extremely frustrating, but I was really pleased to find that I know more than I think (even though I still don't know a lot). I think that this course is a great way to be introduced to Python and get tons of hands-on experience. I am looking forward to applying my skills on the final project.
"""